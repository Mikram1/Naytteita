Salasanageneraattori, joka tekee Suomen sanakirjan perusteella sopivia salasanoja.
L�hdetiedosto n�ille sanoille l�ytyy kotus-sanalista.xml-tiedostosta.
Tehty kahden t�iss� k�ytetyn p��salasanatyypin generoimiseksi: KU-salasanan ja SAP-salasanan.

Ohjelman ajo:
K�ynnist� ohjelma Salasanageneraattori.bat-tiedostosta.
Ennen salasanojen arpomista ohjelman sis�ll� generoi ensin salasanat vastaavasta nappulasta.

KU-salasana:
V�hint��n 15 merkki� pitk�.

SAP-salasana:
V�hint��n 8 merkki� pitk�. Sis�lt�� v�h. 1 numeron & ison kirjaimen. 

- Mikko T